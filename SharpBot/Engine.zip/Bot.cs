﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpBot.Protocol;

namespace SharpBot
{
    class Bot : IBot
    {
        private Player myColor;
        private Stone stackType = Stone.None;

        double pebbleValueEnemy ;
        double rockValueEnemy;
        double boulderValueEnemy;


        public void HandleInitiate(Protocol.InitiateRequest request)
        {
            myColor = request.Color;
        }

        public Protocol.Move HandleMove(Protocol.MoveRequest request)
        {

            var validMoves = new List<Move>();
            foreach (var location in GetMyLocations(request.Board))
            {
                validMoves.AddRange(GetPossibleToLocations(request.Board, location).Select<BoardLocation, Move>(l => CreateMove(request.Board, location, l)).Where(m => m.From != m.To).Where(m => request.AllowedMoves.Contains(m.Type)));
            }

            SetEnemyValues(request.Board);
            var printableValidMoves = validMoves.Select(m => GetPrintableMoveWithDanger(request.Board, m)).OrderBy(m => (m.Danger * 10) - m.Value).ToList();
            return printableValidMoves.First().InnerMove;

            //if ((request.AllowedMoves.Length == 1) && request.AllowedMoves[0] == MoveType.Attack)
            //{
            //    var validMoves = new List<Move>();
            //    foreach (var location in GetMyLocations(request.Board))
            //    {
            //        validMoves.AddRange(GetPossibleToLocations(request.Board, location).Select<BoardLocation, Move>(l => CreateMove(request.Board, location, l)).Where(m => m.From != m.To).Where(m => m.Type == MoveType.Attack));
            //    }

            //    SetEnemyValues(request.Board);
            //    var printableValidMoves = validMoves.Select(m => GetPrintableMoveWithDanger(request.Board, m)).OrderBy(m => (m.Danger * 10) - m.Value).ToList();
            //    return printableValidMoves.First().InnerMove;
            //}
            //else
            //{
            //    var validMoves = new List<Move>();
            //    foreach (var location in GetMyLocations(request.Board))
            //    {
            //        validMoves.AddRange(GetPossibleToLocations(request.Board, location).Select<BoardLocation, Move>(l => CreateMove(request.Board, location, l)).Where(m => m.From != m.To));
            //    }
                
            //    SetEnemyValues(request.Board);
            //    var printableValidMoves = validMoves.Select(m => GetPrintableMoveWithDanger(request.Board, m)).OrderBy(m => (m.Danger * 10) - m.Value).ToList();
            //    return printableValidMoves.First().InnerMove;
                
            //    //validMoves = validMoves.OrderBy(m => GetBoardDangerAndValue(GetNewBoard(request.Board,m))).ToList();


            //    //als mijn hoogste stack niet groter is dan de hoogste van de vijand, wil ik stacken
            //    //of zijn stack slaan...

            //    //roks in danger
            //    //var rocks = GetMyLocations(request.Board).Where(l => request.Board.GetStone(l) == Stone.rock);
            //    //if (rocks.Count() < 4 && rocks.Max(r => request.Board.GetHeight(r) == 1))
            //    //{
            //    //    Move stackMove = doStack(request, Stone.rock);
            //    //    if (stackMove != null)
            //    //    {
            //    //        return stackMove;
            //    //    }
            //    //}

            //    //var pebbles = GetMyLocations(request.Board).Where(l => request.Board.GetStone(l) == Stone.pebble);
            //    //if (pebbles.Count() < 4 && pebbles.Max(r => request.Board.GetHeight(r) == 1))
            //    //{
            //    //    Move stackMove = doStack(request, Stone.pebble);
            //    //    if (stackMove != null)
            //    //    {
            //    //        return stackMove;
            //    //    }
            //    //}

            //    //calculate all possible moves:
            //    //double boardValue;

            //    //foreach (var move in validMoves)
            //    //{
            //    //    CalculateDangerDifference(request.Board,move);
            //    //}





            //    //var myStonesHeight = request.Board.GetHeight(GetMyLocations(request.Board).OrderByDescending(request.Board.GetHeight).First());
            //    //var hisStonesHeight = request.Board.GetHeight(GetHisLocations(request.Board).OrderByDescending(request.Board.GetHeight).First());
            //    //if ((myStonesHeight <= hisStonesHeight) || (!CanAttackHisHighest(request.Board,hisStonesHeight) && hisStonesHeight > 1))
            //    //{
            //    //    Move stackMove = GetStackMove(request);
            //    //    //if no boulders to stack, stack rocks
            //    //    if (stackMove != null)
            //    //    {
            //    //        return stackMove;
            //    //    }
            //    //}
            //    ////identify dangers (a type with < 4 stones, and no stacking)


            //    //return DoAttackMove(request);
            //    //return GetRandomMove(request.Board);
            //}
        }

        private void SetEnemyValues(Board board)
        {
            pebbleValueEnemy = (double)1 / (double)GetHisNumberofStones(board, Stone.pebble);
            rockValueEnemy = (double)1 / (double)GetHisNumberofStones(board, Stone.rock);
            boulderValueEnemy = (double)1 / (double)GetHisNumberofStones(board, Stone.boulder);

        }

        //stone values: 1/amount left
        private double CalculateDangerDifference(Board board, Move move)
        {
            //TODO: fix for 2 enemy attacks
            BoardLocation position = move.From;
            double stoneValue = CalculateStoneValue(board, position);
            double currentRisk = CalculateRisk(board, position);
            double currentDanger = stoneValue * currentRisk;



            double nextHeight = board.GetHeight(move.From);
            if (move.Type == MoveType.Strengthen)
            {
                nextHeight = board.GetHeight(move.From) + board.GetHeight(move.To);
            }
            double nextRisk = GetPossibleToLocations(board, move.To).Where(l => board.GetOwner(l) != myColor && board.GetHeight(l) >= nextHeight).Count();
            double nextDanger = nextRisk * stoneValue;

            return nextDanger - currentDanger;
        }

        //private double GetBoardDangerAndValue(Board board)
        //{
        //    double totalDanger = 0;
        //    double thisValue = ((double)GetHisNumberofStones(board, Stone.pebble) * pebbleValueEnemy) + ((double)GetHisNumberofStones(board, Stone.rock) * rockValueEnemy) + ((double)GetHisNumberofStones(board, Stone.boulder) * boulderValueEnemy);
        //    double totalValue = (3 - thisValue) * 30;
        //    foreach (BoardLocation location in AllLegalBoardLocations())
        //    {
        //        totalDanger += CalculateDanger(board, location);
        //    }
        //    //no boulders left:
        //    if (GetAmountOfSimilar(board, Stone.boulder) == 0)
        //    {
        //        totalDanger = int.MaxValue;
        //    }
        //    if (GetAmountOfSimilar(board, Stone.rock) == 0)
        //    {
        //        totalDanger = int.MaxValue;
        //    }
        //    if (GetAmountOfSimilar(board, Stone.pebble) == 0)
        //    {
        //        totalDanger = int.MaxValue;
        //    }
        //    return totalDanger - totalValue;
        //}
        private PrintableMove GetPrintableMoveWithDanger(Board oldBoard, Move m)
        {

            Board board = GetNewBoard(oldBoard, m);

            double totalDanger = 0;
            double thisValue = ((double)GetHisNumberofStones(board, Stone.pebble) * pebbleValueEnemy) + ((double)GetHisNumberofStones(board, Stone.rock) * rockValueEnemy) + ((double)GetHisNumberofStones(board, Stone.boulder) * boulderValueEnemy);
            double totalValue = (3 - thisValue) * 30;
            foreach (BoardLocation location in AllLegalBoardLocations().Where(l => board.GetOwner(l) == myColor))
            {
                totalDanger += CalculateDanger(board, location);
            }
            //no boulders left:
            if (GetAmountOfSimilar(board, Stone.boulder) == 0)
            {
                totalDanger = int.MaxValue;
            }
            if (GetAmountOfSimilar(board, Stone.rock) == 0)
            {
                totalDanger = int.MaxValue;
            }
            if (GetAmountOfSimilar(board, Stone.pebble) == 0)
            {
                totalDanger = int.MaxValue;
            }
            return new PrintableMove(m,totalDanger,totalValue);
        }

        private Board GetNewBoard(Board oldBoard, Move move)
        {
            Board newBoard = CopyBoard(oldBoard);
            int nextHeight = oldBoard.GetHeight(move.From);
            if (move.Type == MoveType.Strengthen)
            {
                nextHeight = oldBoard.GetHeight(move.From) + oldBoard.GetHeight(move.To);
            }
            newBoard.ClearSpace(move.From);
            var owner = oldBoard.GetOwner(move.From);
            if (owner != Player.None)
            {
                newBoard.SetSpace(move.To, owner, oldBoard.GetStone(move.From), nextHeight);
            }
            else
            {
                Console.Error.WriteLine("grote problemen");
            }
            return newBoard;
        }

        private Board CopyBoard(Board oldBoard)
        {
            int[][] state = new int[9][];
            for (int i = 0; i < 9; i++)
            {
                int[] row = new int[9];

                for (int j = 0; j < 9; j++)
                {
                    row[j] = oldBoard.state[i][j];
                }
                state[i] = row;
            }

            // Board board = new Board(oldBoard);
            return new Board(state);
        }

        private double CalculateDanger(Board board, BoardLocation position)
        {
            double stoneValue = CalculateStoneValue(board, position);
            double risk = CalculateRisk(board, position);
            double danger = stoneValue * risk;
            return danger;
        }

        private double CalculateStoneValue(Board board, BoardLocation position)
        {
            var currentStone = board.GetStone(position);
            if (currentStone == Stone.None)
            {
                return 0;
            }
            int numberOfSimilar = GetAmountOfSimilar(board, currentStone);
            double stoneValue = 1.0 / (double)(numberOfSimilar * numberOfSimilar);
            stoneValue *= board.GetHeight(position);
            return stoneValue;
        }

        private int GetAmountOfSimilar(Board board, Stone stone)
        {
            int numberOfSimilar = GetMyLocations(board).Count(l => board.GetStone(l) == stone);
            return numberOfSimilar;
        }

        private double CalculateRisk(Board board, BoardLocation position)
        {
            double risk = GetPossibleFromLocations(board, position).Where(l => board.GetOwner(l) != myColor && board.GetHeight(l) >= board.GetHeight(position)).Count();
            //second step: 
            foreach (var location in GetPossibleToLocations(board, position).Where(p => board.GetOwner(p) == myColor))
            {
                //elke dude die mij kan slaan, en de dude op position
                risk += GetPossibleFromLocations(board, location).Where(l => board.GetOwner(l) != myColor && board.GetHeight(l) >= board.GetHeight(location) && board.GetHeight(l) >= board.GetHeight(position)).Count();
            }
            var currentStone = board.GetStone(position);
            int amountLeft = GetAmountOfSimilar(board, currentStone);
            if ( amountLeft < 3)
            {
                risk *= 10*(3-amountLeft);
            }
            return risk ;//> 0 ? 1 : 0;
        }



        private Move CreateMove(Board board, BoardLocation from, BoardLocation to)
        {
            if (board.GetOwner(to) == myColor)
            {
                return new Move(MoveType.Strengthen, from, to);
            }
            else
            {
                return new Move(MoveType.Attack, from, to);
            }
        }

        private bool CanAttackHisHighest(Board board, int highest)
        {
            var hisHighest = GetHisLocations(board).Where(l => board.GetHeight(l) == highest);
            return hisHighest.Any(l => GetPossibleToLocations(board, l).Intersect(GetMyLocations(board).Where(x => board.GetHeight(x) >= highest)).Count() > 0);
        }

        private Move GetStackMove(Protocol.MoveRequest request)
        {
            //stack boulders
            //does it make sense to stack boulders>
            List<Stone> stoneTypes = new List<Stone> { Stone.boulder, Stone.rock, Stone.pebble };
            stoneTypes.OrderByDescending(l => GetNumberofStones(request.Board, l));
            return doStack(request, stoneTypes[0]) ?? doStack(request, stoneTypes[1]) ?? doStack(request, stoneTypes[2]) ?? null;
        }

        private Move doStack(Protocol.MoveRequest request, Stone stone)
        {
            Move move = null;
            var myBouldersMaxHeight = GetMyLocations(request.Board).Where(s => request.Board.GetStone(s) == stone).Max(s => request.Board.GetHeight(s));
            var hisBouldersMaxHeight = GetHisLocations(request.Board).Max(s => request.Board.GetHeight(s));
            if (myBouldersMaxHeight <= hisBouldersMaxHeight)
            {
                move = getStack(request.Board, stone);

            }
            return move;
        }

        private Move getStack(Board board, Stone stone)
        {
            try
            {
                var mystones = GetMyLocations(board);
                var myStonesToStack = mystones.Where(l => board.GetStone(l) == stone);
                var highestStone = (from s in myStonesToStack orderby board.GetHeight(s) descending select s).First();
                var stackee = (from s in GetPossibleToLocations(board, highestStone).Intersect(mystones.ToList()) where (board.GetStone(s) < board.GetStone(highestStone) || (board.GetStone(s) == Stone.pebble && highestStone != s)) && board.GetTotalCount(myColor, board.GetStone(s)) > 1 select s).First();
                if (!mystones.Contains(stackee))
                {
                    throw new Exception("wut?");
                }
                return new Move(MoveType.Strengthen, highestStone, stackee);
            }
            catch (Exception ex)
            {
                //Console.Error.WriteLine(ex.Message);
                return null;
            }
        }

        private IEnumerable<BoardLocation> GetMyLocations(Board board)
        {
            var mystones = AllLegalBoardLocations().Where(l => board.GetOwner(l) == myColor);
            return mystones;
        }

        private IEnumerable<BoardLocation> GetHisLocations(Board board)
        {
            var hisStones = AllLegalBoardLocations().Where(l => board.GetOwner(l) != myColor);
            return hisStones;
        }

        private Move DoAttackMove(Protocol.MoveRequest request)
        {
            //if i can attack boulders, do so
            //attack the type which he has least of <- todo
            List<Stone> stoneTypes = new List<Stone> { Stone.boulder, Stone.rock, Stone.pebble };
            stoneTypes.OrderByDescending(l => GetHisNumberofStones(request.Board, l));

            return getAttack(request.Board, stoneTypes[0]) ?? getAttack(request.Board, stoneTypes[1]) ?? getAttack(request.Board, stoneTypes[2]) ?? GetRandomAttack(request.Board);
        }

        int GetHisNumberofStones(Board board, Stone stone)
        {
            return GetHisLocations(board).Where(l => board.GetStone(l) == stone).Count();
        }

        int GetNumberofStones(Board board, Stone stone)
        {
            return GetMyLocations(board).Where(l => board.GetStone(l) == stone).Count();
        }

        private Move getAttack(Board board, Stone stone)
        {
            //getpossibletolocations
            try
            {
                var attackableBoulders = AllLegalBoardLocations().Where(l => (board.GetOwner(l) != myColor)).Where(l => (board.GetStone(l) == stone) && GetPossibleToLocations(board, l).Any(p => board.GetOwner(p) == myColor && board.GetHeight(p) >= board.GetHeight(l))).OrderByDescending(board.GetHeight).ToList();
                return new Move(MoveType.Attack, GetPossibleToLocations(board, attackableBoulders[0]).First(p => board.GetOwner(p) == myColor && board.GetHeight(p) >= board.GetHeight(attackableBoulders[0])), attackableBoulders[0]);
            }
            catch
            {
                return null;
            }
        }

        public void HandleProcessedMove(Protocol.ProcessedMove move)
        {
            // Ignore what the other did
        }

        private static readonly Random random = new Random();

        private Move GetRandomMove(Board board)
        {
            var myLocations = AllLegalBoardLocations().Where(l => board.GetOwner(l) == myColor);

            var fromLocation = myLocations.ElementAt(random.Next(myLocations.Count()));

            var possibleToLocations = GetPossibleToLocations(board, fromLocation);

            var toLocation = possibleToLocations.ElementAt(random.Next(possibleToLocations.Count));

            if (toLocation == fromLocation)
            {
                return new Move(MoveType.Pass, null, null);
            }
            else if (board.GetOwner(toLocation) != myColor)
            {
                return new Move(MoveType.Attack, fromLocation, toLocation);
            }
            else
            {
                return new Move(MoveType.Strengthen, fromLocation, toLocation);
            }
        }

        private Move GetRandomAttack(Board board)
        {
            Move move = GetRandomMove(board);
            while (move.Type != MoveType.Attack)
            {
                move = GetRandomMove(board);
            }
            return move;
        }

        private static List<BoardLocation> GetPossibleToLocations(Board board, BoardLocation fromLocation)
        {
            List<BoardLocation> possibleToLocations = new List<BoardLocation>();

            // always possible to pass
            possibleToLocations.Add(fromLocation);

            BoardLocation north = GetFirstNonEmptyInDirection(board, fromLocation, 0, -1);
            if (north != null && IsValidMove(board, fromLocation, north)) possibleToLocations.Add(north);

            BoardLocation south = GetFirstNonEmptyInDirection(board, fromLocation, 0, 1);
            if (south != null && IsValidMove(board, fromLocation, south)) possibleToLocations.Add(south);

            BoardLocation east = GetFirstNonEmptyInDirection(board, fromLocation, 1, 0);
            if (east != null && IsValidMove(board, fromLocation, east)) possibleToLocations.Add(east);

            BoardLocation west = GetFirstNonEmptyInDirection(board, fromLocation, -1, 0);
            if (west != null && IsValidMove(board, fromLocation, west)) possibleToLocations.Add(west);

            BoardLocation northWest = GetFirstNonEmptyInDirection(board, fromLocation, -1, -1);
            if (northWest != null && IsValidMove(board, fromLocation, northWest)) possibleToLocations.Add(northWest);

            BoardLocation southEast = GetFirstNonEmptyInDirection(board, fromLocation, 1, 1);
            if (southEast != null && IsValidMove(board, fromLocation, southEast)) possibleToLocations.Add(southEast);
            return possibleToLocations;
        }

        private static List<BoardLocation> GetPossibleFromLocations(Board board, BoardLocation toLocation)
        {
            List<BoardLocation> possibleFromLocations = new List<BoardLocation>();

            // always possible to pass
            //possibleFromLocations.Add(toLocation);

            BoardLocation north = GetFirstNonEmptyInDirection(board, toLocation, 0, -1);
            if (north != null && IsValidMove(board, north, toLocation)) possibleFromLocations.Add(north);

            BoardLocation south = GetFirstNonEmptyInDirection(board, toLocation, 0, 1);
            if (south != null && IsValidMove(board, south, toLocation)) possibleFromLocations.Add(south);

            BoardLocation east = GetFirstNonEmptyInDirection(board, toLocation, 1, 0);
            if (east != null && IsValidMove(board, east, toLocation)) possibleFromLocations.Add(east);

            BoardLocation west = GetFirstNonEmptyInDirection(board, toLocation, -1, 0);
            if (west != null && IsValidMove(board, west, toLocation)) possibleFromLocations.Add(west);

            BoardLocation northWest = GetFirstNonEmptyInDirection(board, toLocation, -1, -1);
            if (northWest != null && IsValidMove(board, northWest, toLocation)) possibleFromLocations.Add(northWest);

            BoardLocation southEast = GetFirstNonEmptyInDirection(board, toLocation, 1, 1);
            if (southEast != null && IsValidMove(board, southEast, toLocation)) possibleFromLocations.Add(southEast);
            return possibleFromLocations;
        }

        private static BoardLocation GetFirstNonEmptyInDirection(Board board, BoardLocation location, int directionX, int directionY)
        {
            int x = location.X;
            int y = location.Y;

            do
            {
                x += directionX;
                y += directionY;
            } while (BoardLocation.IsLegal(x, y) && (board.GetOwner(new BoardLocation(x, y)) == Player.None));

            if (!BoardLocation.IsLegal(x, y))
            {
                return null;
            }

            BoardLocation newLocation = new BoardLocation(x, y);
            if (newLocation == location ||
                board.GetOwner(newLocation) == Player.None)
            {
                return null;
            }
            else
            {
                return newLocation;
            }
        }

        private static bool IsValidMove(Board board, BoardLocation from, BoardLocation to)
        {
            Player fromOwner = board.GetOwner(from);
            Player toOwner = board.GetOwner(to);
            int fromHeight = board.GetHeight(from);
            int toHeight = board.GetHeight(to);
            return (fromOwner != Player.None) &&
                (toOwner != Player.None) &&
                (fromOwner == toOwner || fromHeight >= toHeight);
        }

        private static IEnumerable<BoardLocation> AllLegalBoardLocations()
        {
            for (int y = 0; y < 9; y++)
            {
                for (int x = 0; x < 9; x++)
                {
                    if (BoardLocation.IsLegal(x, y))
                    {
                        yield return new BoardLocation(x, y);
                    }
                }
            }
        }

    }
}
