﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpBot.Protocol
{
    public enum Stone : int
    {
        None = 0,
        pebble = 1, //pebble
        rock = 2, //rock
        boulder = 3, //boulder
    }
}
