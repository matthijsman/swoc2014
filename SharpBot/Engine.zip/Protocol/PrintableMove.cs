﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpBot.Protocol
{
    public class PrintableMove : Move
    {

        private string[] X = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I" };
        private string[] Y = new string[] { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

        public double Danger;
        public double Value;
        public Move InnerMove;

        public PrintableMove(Move move, double danger, double value) : base(move.Type,move.From,move.To)
        {
            Danger = danger;
            Value = value;
            InnerMove = move;
        }

        public override string ToString()
        {
            return "Type: " + base.Type.ToString() + " From: " + GetString(base.From.X, base.From.Y) + " To: " + GetString(base.To.X, base.To.Y);
        }

        private string GetString(int x, int y)
        {
            if (x > 4) y--;
            if (x > 5) y--;
            if (x > 6) y--;
            if (x > 7) y--;
            return X[x] + Y[y];
        }
    }
}
