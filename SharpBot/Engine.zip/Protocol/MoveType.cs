﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpBot.Protocol
{
    public enum MoveType : int
    {
        Pass = 0,
        Attack = 1,
        Strengthen = 2,
    };
}
